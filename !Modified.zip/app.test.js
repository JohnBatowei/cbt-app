const axios = require("axios");

const BASE_URL = "http://localhost:3800"; // Replace with your actual API base URL

// List of API endpoints to test
const endpoints = [
  { method: "GET", url: "/api/api/index" },
//   { method: "GET", url: "/api/st" },
//   { method: "POST", url: "/api-test", data: { key: "value" } },
//   { method: "GET", url: "/api/unknown" }, // Example unknown endpoint for testing
];

// Function to test a single endpoint
const testEndpoint = async ({ method, url, data }) => {
  const startTime = Date.now();
  try {
    const response = await axios({
      method,
      url: `${BASE_URL}${url}`,
      data,
    });
    const endTime = Date.now();
    console.log(`[PASS] ${method} ${url} - ${response.status} - ${endTime - startTime}ms`);
  } catch (error) {
    const endTime = Date.now();
    if (error.response) {
      console.log(`[FAIL] ${method} ${url} - ${error.response.status} - ${endTime - startTime}ms`);
    } else {
      console.log(`[ERROR] ${method} ${url} - ${error.message}`);
    }
  }
};

// Function to run the test for all endpoints
const runTests = async (concurrentRequests = 700) => {
  console.log(`Starting tests with ${concurrentRequests} concurrent requests...\n`);

  for (const endpoint of endpoints) {
    const promises = [];
    for (let i = 0; i < concurrentRequests; i++) {
      promises.push(testEndpoint(endpoint));
    }
    await Promise.all(promises);
    console.log(`\nFinished testing ${endpoint.method} ${endpoint.url}\n`);
  }

  console.log("All tests completed.");
};

// Run tests with 10 concurrent requests per endpoint
runTests(700);
